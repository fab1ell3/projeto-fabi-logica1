/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main() {
    int n, i, j, temp;
    char continuar;

    do {
        printf("\nQuantos números você quer ordenar? ");
        scanf("%d", &n);

        int numeros[n];

       
        printf("Digite os %d números:\n", n);
        for (i = 0; i < n; i++) {
            printf("Número %d: ", i + 1);
            scanf("%d", &numeros[i]);
        }

              for (i = 0; i < n - 1; i++) {
            for (j = 0; j < n - i - 1; j++) {
                if (numeros[j] > numeros[j + 1]) {
                    temp = numeros[j];
                    numeros[j] = numeros[j + 1];
                    numeros[j + 1] = temp;
                }
            }
        }

     
        printf("\nNúmeros em ordem crescente:\n");
        for (i = 0; i < n; i++) {
            printf("%d ", numeros[i]);
        }
        printf("\n");

        // Pergunta se o usuário quer repetir
        printf("\nDeseja ordenar outro conjunto de números? (s/n): ");
        scanf(" %c", &continuar); // o espaço antes de %c ignora o ENTER anterior

    } while (continuar == 's' || continuar == 'S');

    printf("\nPrograma encerrado. Até a próxima!\n");

    return 0;
}

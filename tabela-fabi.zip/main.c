/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int contador = 0;
    while (1) {
        printf("Contador: %d\n", contador);
        contador++;

    char nome[50];
    int idade, numero_telefone;
    float peso, altura;
    char sexo;
 
    printf("=== Sistema Cadastro ===\n\n");
 
    printf("Digite o nome: ");
    scanf("%49s", nome);
   
    printf("Digite sua idade: ");
    scanf("%d", &idade);

    printf("Digite sua altura: ");
    scanf("%f", &altura);

    printf("Digite seu peso: ");
    scanf("%f", &peso);
   
    printf("Digite o seu sexo: ");
    scanf(" %49s", &sexo);

    printf("Digite seu numero: ");
    scanf("%d", &numero_telefone);
    
    printf("\n=== Dados Cadastrados ===\n");
    printf("Nome: %s\n", nome);
    printf("Idade: %d anos\n", idade);
    printf("Altura: %.2f metros\n", altura);
    printf("Peso: %.2f kg\n", peso);
    printf("Sexo: %c\n", sexo);
    printf("Numero do telefone: %d\n", numero_telefone);
   
    if (contador >= 5) { // Condição para parar
            break; // Sai do loop
        }
    }
    printf("Loop interrompido!\n");
    return 0;
   
}

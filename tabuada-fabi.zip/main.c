/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main () {
    int n;
    int i;
    do {
    printf ("digite um número \n(digite 0 para para encerrar o programa): ");
    scanf ("%d",&n);

     printf("tabuada do número:\n");
     for (i = 1; i <= 10; i++) {
        printf("%d X %d = %d\n", i, n, i * n);
    }
    } while (n != 0);
    return 0;
}
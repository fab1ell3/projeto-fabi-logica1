/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

//variaveis
int main () {
    int n;
    int i;
    do {
//digite um número que deseja,e armazena ele.      
    printf ("digite um número \n(digite 0 para para encerrar o programa): ");//condição para encerrar
    scanf ("%d",&n);
    
//mostra a tabuada
     printf("tabuada do número:\n");
     for (i = 1; i <= 10; i++) {
        printf("%d X %d = %d\n", i, n, i * n);
    }
//loop    
    } while (n != 0);
    return 0;
}
/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int contador = 0;
    while (1) {
        printf("Contador: %d\n", contador);
        contador++;
//variaveis
    char nome[50];
    int idade, numero_telefone;
    float peso, altura;
    char sexo;
 
//sistema para o cadastro
    printf("=== Sistema Cadastro ===\n\n");
 
//escreva seu nome
    printf("Digite o nome: ");
    scanf("%49s", nome);
   
//escreva a sua idade
    printf("Digite sua idade: ");
    scanf("%d", &idade);

//coloque a sua altura
    printf("Digite sua altura: ");
    scanf("%f", &altura);

//escreva o seu peso
    printf("Digite seu peso: ");
    scanf("%f", &peso);
   
//coloque qual o seu sexo
    printf("Digite o seu sexo: ");
    scanf(" %49s", &sexo);

//seu número de telefone
    printf("Digite seu numero: ");
    scanf("%d", &numero_telefone);
    
    printf("\n=== Dados Cadastrados ===\n");
    printf("Nome: %s\n", nome);
    printf("Idade: %d anos\n", idade);
    printf("Altura: %.2f metros\n", altura);
    printf("Peso: %.2f kg\n", peso);
    printf("Sexo: %c\n", sexo);
    printf("Numero do telefone: %d\n", numero_telefone);
   
//loop
    if (contador >= 5) { // Condição para parar
            break; // Sai do loop
        }
    }
    printf("Loop interrompido!\n");
    return 0;
   
}
